const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (email === "user@example.com" && password === "1234") {
      sessionStorage.setItem("loggedIn", "true");
      sessionStorage.setItem("username", email);
      window.location.href = "index.html";
    } else {
      document.getElementById("error").textContent =
        "Invalid login. Use user@example.com / 1234";
    }
  });
}

if (
  !window.location.pathname.includes("login.html") &&
  !window.location.pathname.includes("thankyou.html")
) {
  if (sessionStorage.getItem("loggedIn") !== "true") {
    window.location.href = "login.html";
  }
}

function logout() {
  sessionStorage.clear();
  window.location.href = "login.html";
}


async function loadProducts(category) {
  try {
    const response = await fetch("data/products.json");
    const products = await response.json();

    const productList = document.getElementById("product-list");
    if (!productList) return;

    const filtered = products.filter((p) => p.category === category);

    filtered.forEach((product) => {
      const div = document.createElement("div");
      div.classList.add("product-card");

      div.innerHTML = `
        <img src="${product.image}" alt="${product.name}">
        <h4>${product.name}</h4>
        <p>$${product.price.toFixed(2)}</p>
        <button onclick="addToCart(${product.id}, '${product.name}', ${product.price}, '${product.image}')">Add to Cart</button>
      `;

      productList.appendChild(div);
    });
  } catch (error) {
    console.error("Error loading products:", error);
  }
}


function getCart() {
  return JSON.parse(sessionStorage.getItem("cart")) || [];
}

function saveCart(cart) {
  sessionStorage.setItem("cart", JSON.stringify(cart));
}

function addToCart(id, name, price, image) {
  let cart = getCart();
  const existing = cart.find((item) => item.id === id);

  if (existing) {
    existing.quantity++;
  } else {
    cart.push({ id, name, price, image, quantity: 1 });
  }

  saveCart(cart);
  alert(`${name} added to cart!`);
}

function renderCart() {
  const cartItems = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");

  if (!cartItems || !cartTotal) return;

  let cart = getCart();
  cartItems.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price * item.quantity;

    const div = document.createElement("div");
    div.classList.add("cart-item");
    div.innerHTML = `
      <span><img src="${item.image}" alt="${item.name}" width="50"> ${item.name}</span>
      <span>$${item.price.toFixed(2)} x ${item.quantity}</span>
      <button onclick="removeFromCart(${index})">Remove</button>
    `;

    cartItems.appendChild(div);
  });

  cartTotal.textContent = total.toFixed(2);
}

function removeFromCart(index) {
  let cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
  renderCart();
}


const checkoutForm = document.getElementById("checkoutForm");
if (checkoutForm) {
  checkoutForm.addEventListener("submit", function (e) {
    e.preventDefault();
    sessionStorage.removeItem("cart");
    window.location.href = "thankyou.html";
  });
}


document.addEventListener("DOMContentLoaded", () => {
  if (window.location.pathname.includes("skincare.html")) {
    loadProducts("skincare");
  }
  if (window.location.pathname.includes("makeup.html")) {
    loadProducts("makeup");
  }
  if (window.location.pathname.includes("electronics.html")) {
    loadProducts("electronics");
  }
  if (window.location.pathname.includes("cart.html")) {
    renderCart();
  }
});